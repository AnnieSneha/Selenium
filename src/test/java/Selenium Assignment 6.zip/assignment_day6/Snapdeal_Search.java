package assignment_day6;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Snapdeal_Search {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.snapdeal.com/");
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		js.executeScript("document.getElementById(\"inputValEnter\").value='Tshirt'"); 
		
		String script = "document.getElementsByClassName('searchformButton')[0].click();";
		((JavascriptExecutor) driver).executeScript(script);

		
		
		//driver.close();

	}

}
